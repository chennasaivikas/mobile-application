List<int> listNumbers(String testNumber) {
  int number = int.tryParse(testNumber) ?? 0;
  List<int> mynumberfs = List.generate(10, (index) => index + number);
  return mynumberfs;
}
