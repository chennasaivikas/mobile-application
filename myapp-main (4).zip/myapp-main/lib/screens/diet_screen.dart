import 'package:flutter/material.dart';

class DietScreen extends StatelessWidget {
  final List<Map<String, String>> dietTips = [
    {'title': 'Stay Hydrated', 'tip': 'Drink at least 8 glasses of water daily.'},
    {'title': 'Eat More Greens', 'tip': 'Add leafy vegetables to every meal.'},
    {'title': 'Balanced Meals', 'tip': 'Include protein, carbs, and fats in the right ratio.'},
    {'title': 'Avoid Sugar', 'tip': 'Reduce processed sugar to stay fit.'},
  ];

   DietScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Diet Tips'),
        centerTitle: true,
        backgroundColor: Colors.pinkAccent, // AppBar color
      ),
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFFFFDEE9), // Light pink
              Color(0xFFB5FFFC), // Light blue
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: ListView.builder(
            padding: EdgeInsets.all(16),
            itemCount: dietTips.length,
            itemBuilder: (context, index) {
              return Card(
                margin: EdgeInsets.only(bottom: 16),
                child: ListTile(
                  leading: Icon(Icons.local_dining, color: Colors.pink, size: 30),
                  title: Text(dietTips[index]['title']!),
                  subtitle: Text(dietTips[index]['tip']!),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
