import 'package:flutter/material.dart';
import 'workout_timer_screen.dart'; // Import the new timer screen

class WorkoutScreen extends StatelessWidget {
  const WorkoutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Workout Plans'),
        centerTitle: true,
        backgroundColor: Colors.pinkAccent,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(), // Go back
        ),
      ),
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFFFFDEE9), // Light pink
              Color(0xFFB5FFFC), // Light cyan
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: ListView(
            padding: EdgeInsets.all(16),
            children: [
              workoutCard(context, 'Full Body Workout', 30),
              workoutCard(context, 'Yoga for Flexibility', 20),
              workoutCard(context, 'Cardio Blast', 25),
              workoutCard(context, 'Core Strength', 15),
            ],
          ),
        ),
      ),
    );
  }

  Widget workoutCard(BuildContext context, String title, int minutes) {
    return Card(
      margin: EdgeInsets.only(bottom: 16),
      child: ListTile(
        leading: Icon(Icons.fitness_center, size: 32, color: Colors.pink),
        title: Text(title, style: TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text('$minutes mins'),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => WorkoutTimerScreen(title: title, minutes: minutes),
            ),
          );
        },
      ),
    );
  }
}
