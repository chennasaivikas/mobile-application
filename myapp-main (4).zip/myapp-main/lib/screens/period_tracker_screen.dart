import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class PeriodTrackerScreen extends StatefulWidget {
  const PeriodTrackerScreen({super.key});

  @override
  _PeriodTrackerScreenState createState() => _PeriodTrackerScreenState();
}

class _PeriodTrackerScreenState extends State<PeriodTrackerScreen> {
  DateTime? _lastPeriodDate;
  String _nextPeriodDate = '';
  String _reminderMessage = '';

  void _calculateNextPeriodAndReminder() {
    if (_lastPeriodDate != null) {
      DateTime nextPeriod = _lastPeriodDate!.add(Duration(days: 28));
      setState(() {
        _nextPeriodDate = DateFormat('yyyy-MM-dd').format(nextPeriod);

        // Calculate how close the next period is and show safety tips accordingly
        int daysUntilNextPeriod = nextPeriod.difference(DateTime.now()).inDays;
        if (daysUntilNextPeriod <= 7) {
          _reminderMessage = 'Your period is coming soon. Be ready!';
        } else if (daysUntilNextPeriod <= 14) {
          _reminderMessage = 'Your period is in about two weeks.';
        } else {
          _reminderMessage = 'Stay aware of your cycle.';
        }
      });
    }
  }

  Future<void> _pickDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _lastPeriodDate ?? DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null) {
      setState(() {
        _lastPeriodDate = picked;
        _nextPeriodDate = '';
        _reminderMessage = '';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Period Tracker'),
        backgroundColor: Colors.pinkAccent,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(), // Go back
        ),
      ),
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFFFFDEE9),
              Color(0xFFB5FFFC),
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const SizedBox(height: 30),
                Text(
                  'Track your period and\nstay in control!',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: Colors.pinkAccent,
                  ),
                ),
                const SizedBox(height: 30),

                ElevatedButton(
                  onPressed: _pickDate,
                  style: _buttonStyle(),
                  child: Text(
                    _lastPeriodDate == null
                        ? 'Pick Last Period Date'
                        : 'Change Last Period: ${DateFormat('yyyy-MM-dd').format(_lastPeriodDate!)}',
                  ),
                ),
                const SizedBox(height: 20),

                ElevatedButton(
                  onPressed: _calculateNextPeriodAndReminder,
                  style: _buttonStyle(),
                  child: Text('Submit'),
                ),
                const SizedBox(height: 30),

                if (_nextPeriodDate.isNotEmpty)
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.pinkAccent.withOpacity(0.3),
                          blurRadius: 10,
                          offset: Offset(0, 5),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        Text(
                          'Next Expected Period:',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.pinkAccent,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          _nextPeriodDate,
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: Colors.blueAccent,
                          ),
                        ),
                        const SizedBox(height: 20),
                        Divider(color: Colors.pinkAccent),
                        const SizedBox(height: 10),
                        Text(
                          'Safety Reminder:',
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            color: const Color.fromARGB(255, 93, 64, 255),
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          _reminderMessage,
                          style: TextStyle(
                            fontSize: 12, // Small size for a subtle hint
                            color: Colors.black45, // Lighter color to keep it subtle
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  ButtonStyle _buttonStyle() {
    return ElevatedButton.styleFrom(
      backgroundColor: Colors.white,
      foregroundColor: Colors.pinkAccent,
      padding: EdgeInsets.symmetric(horizontal: 30, vertical: 16),
      textStyle: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(30),
      ),
      elevation: 5,
    );
  }
}
