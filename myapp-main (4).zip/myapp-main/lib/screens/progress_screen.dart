import 'package:flutter/material.dart';

class ProgressScreen extends StatefulWidget {
  const ProgressScreen({super.key});

  @override
  _ProgressScreenState createState() => _ProgressScreenState();
}

class _ProgressScreenState extends State<ProgressScreen> {
  // Example progress data
  final List<Map<String, String>> progressData = [
    {'title': 'Full Body Workout', 'status': 'Completed'},
    {'title': 'Yoga for Flexibility', 'status': 'Not Completed'},
    {'title': 'Cardio Blast', 'status': 'Completed'},
    {'title': 'Core Strength', 'status': 'Not Completed'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Progress Tracker'),
        centerTitle: true,
        backgroundColor: Colors.pinkAccent, // Matching AppBar color
      ),
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFFFFDEE9), // Light pink
              Color(0xFFB5FFFC), // Light blue
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: ListView.builder(
            padding: EdgeInsets.all(16),
            itemCount: progressData.length,
            itemBuilder: (context, index) {
              return Card(
                margin: EdgeInsets.only(bottom: 16),
                child: ListTile(
                  leading: Icon(
                    progressData[index]['status'] == 'Completed'
                        ? Icons.check_circle
                        : Icons.cancel,
                    color: progressData[index]['status'] == 'Completed'
                        ? Colors.green
                        : Colors.red,
                    size: 30,
                  ),
                  title: Text(progressData[index]['title']!),
                  subtitle: Text('Status: ${progressData[index]['status']}'),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
