import 'package:flutter/material.dart';
import 'workout_screen.dart';
import 'diet_screen.dart';
import 'progress_screen.dart';
import 'period_tracker_screen.dart';
import 'bmi_calculator_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

   _popUpAboutWindow(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('About us'),
          content: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text("Women Fitness App Created by:",style: TextStyle(fontSize: 15,color: Colors.blue,fontWeight: FontWeight.bold),),
              const SizedBox(height: 10),
              const Text("Dineshkumar"),
              const Text("SaiVikas"),
              const Text("Hanmandlu"),
              const Text("Darshan"),
          
            ],
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Close'),
              onPressed: () => Navigator.of(context).pop(),
            )],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFFFFDEE9), Color(0xFFB5FFFC)],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
              child: Center(
                child: SingleChildScrollView(
                  child: Padding(
                    padding: const EdgeInsets.all(24.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const SizedBox(height: 40), // Space at top
                        Text(
                          'Welcome to\nWomen Fitness!',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 32,
                            fontWeight: FontWeight.bold,
                            color: Colors.pinkAccent,
                          ),
                        ),
                        const SizedBox(height: 40),

                        // Wrap the buttons in a SizedBox for equal width
                        _buildRoundedButton(
                          context,
                          '🏋️‍♀️',
                          'Start Workout',
                          WorkoutScreen(),
                        ),
                        _buildRoundedButton(
                          context,
                          '🍎',
                          'Diet Tips',
                          DietScreen(),
                        ),
                        _buildRoundedButton(
                          context,
                          '📈',
                          'Progress Tracker',
                          ProgressScreen(),
                        ),
                        _buildRoundedButton(
                          context,
                          '🩸',
                          'Period Tracker',
                          PeriodTrackerScreen(),
                        ),
                        _buildRoundedButton(
                          context,
                          '⚖️',
                          'BMI Calculator',
                          BMICalculatorScreen(),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            top: 20,
            right: 20,
            child: IconButton(
              onPressed: () {
                _popUpAboutWindow(context);
              },
              icon: Icon(Icons.info, color: Colors.blue, size: 30),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRoundedButton(
    BuildContext context,
    String iconString,
    String title,
    Widget page,
  ) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: SizedBox(
        width: double.infinity, // Set the width to occupy full width
        height: 60, // Set a fixed height for all buttons
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.white,
            foregroundColor: Colors.pinkAccent,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(30),
            ),
            elevation: 5,
            textStyle: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => page),
            );
          },
          child: Padding(
            padding: const EdgeInsets.only(left: 40),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(flex: 1, child: Text(iconString)),
                Expanded(flex: 5, child: Text(title)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
